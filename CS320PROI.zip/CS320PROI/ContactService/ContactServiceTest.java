package contactservice;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class ContactServiceTest {

    private ContactService service;

    @BeforeEach
    void setUp() {
        service = new ContactService();
    }

    @Test
    void testAddContact() {
        Contact contact = new Contact(
                "12345",
                "Julian",
                "Tovar",
                "3001234567",
                "Bogota"
        );

        service.addContact(contact);

        assertEquals(contact, service.getContact("12345"));
    }

    @Test
    void testCannotAddDuplicateContactId() {
        Contact contact1 = new Contact(
                "12345", "Julian", "Tovar",
                "3001234567", "Bogota"
        );

        Contact contact2 = new Contact(
                "12345", "Carlos", "Perez",
                "3011234567", "Medellin"
        );

        service.addContact(contact1);

        assertThrows(IllegalArgumentException.class, () ->
                service.addContact(contact2)
        );
    }

    @Test
    void testDeleteContact() {
        Contact contact = new Contact(
                "12345", "Julian", "Tovar",
                "3001234567", "Bogota"
        );

        service.addContact(contact);
        service.deleteContact("12345");

        assertThrows(IllegalArgumentException.class, () ->
                service.getContact("12345")
        );
    }

    @Test
    void testUpdateFirstName() {
        Contact contact = new Contact(
                "12345", "Julian", "Tovar",
                "3001234567", "Bogota"
        );

        service.addContact(contact);
        service.updateFirstName("12345", "Carlos");

        assertEquals("Carlos", service.getContact("12345").getFirstName());
    }

    @Test
    void testUpdateLastName() {
        Contact contact = new Contact(
                "12345", "Julian", "Tovar",
                "3001234567", "Bogota"
        );

        service.addContact(contact);
        service.updateLastName("12345", "Perez");

        assertEquals("Perez", service.getContact("12345").getLastName());
    }

    @Test
    void testUpdatePhone() {
        Contact contact = new Contact(
                "12345", "Julian", "Tovar",
                "3001234567", "Bogota"
        );

        service.addContact(contact);
        service.updatePhone("12345", "3019876543");

        assertEquals("3019876543", service.getContact("12345").getPhone());
    }

    @Test
    void testUpdateAddress() {
        Contact contact = new Contact(
                "12345", "Julian", "Tovar",
                "3001234567", "Bogota"
        );

        service.addContact(contact);
        service.updateAddress("12345", "Medellin");

        assertEquals("Medellin", service.getContact("12345").getAddress());
    }
}