package contactservice;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import org.junit.jupiter.api.Test;

class ContactTest {

    @Test
    void testValidContact() {
        Contact contact = new Contact(
                "12345",
                "Julian",
                "Tovar",
                "3001234567",
                "Bogota Colombia"
        );

        assertEquals("12345", contact.getContactId());
        assertEquals("Julian", contact.getFirstName());
        assertEquals("Tovar", contact.getLastName());
        assertEquals("3001234567", contact.getPhone());
        assertEquals("Bogota Colombia", contact.getAddress());
    }

    @Test
    void testContactIdCannotBeNull() {
        assertThrows(IllegalArgumentException.class, () ->
                new Contact(null, "Julian", "Tovar",
                        "3001234567", "Bogota")
        );
    }

    @Test
    void testContactIdCannotExceed10Characters() {
        assertThrows(IllegalArgumentException.class, () ->
                new Contact("12345678901", "Julian", "Tovar",
                        "3001234567", "Bogota")
        );
    }

    @Test
    void testFirstNameCannotBeNull() {
        assertThrows(IllegalArgumentException.class, () ->
                new Contact("12345", null, "Tovar",
                        "3001234567", "Bogota")
        );
    }

    @Test
    void testFirstNameCannotExceed10Characters() {
        assertThrows(IllegalArgumentException.class, () ->
                new Contact("12345", "Julian123456", "Tovar",
                        "3001234567", "Bogota")
        );
    }

    @Test
    void testLastNameCannotBeNull() {
        assertThrows(IllegalArgumentException.class, () ->
                new Contact("12345", "Julian", null,
                        "3001234567", "Bogota")
        );
    }

    @Test
    void testPhoneMustHave10Digits() {
        assertThrows(IllegalArgumentException.class, () ->
                new Contact("12345", "Julian", "Tovar",
                        "12345", "Bogota")
        );
    }

    @Test
    void testPhoneCannotBeNull() {
        assertThrows(IllegalArgumentException.class, () ->
                new Contact("12345", "Julian", "Tovar",
                        null, "Bogota")
        );
    }

    @Test
    void testAddressCannotBeNull() {
        assertThrows(IllegalArgumentException.class, () ->
                new Contact("12345", "Julian", "Tovar",
                        "3001234567", null)
        );
    }

    @Test
    void testAddressCannotExceed30Characters() {
        assertThrows(IllegalArgumentException.class, () ->
                new Contact(
                        "12345",
                        "Julian",
                        "Tovar",
                        "3001234567",
                        "Esta direccion tiene mas de treinta caracteres"
                )
        );
    }
}