import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.util.Date;

import org.junit.jupiter.api.Test;

public class AppointmentTest {

    @Test
    void testAppointmentCreation() {
        Date futureDate = new Date(System.currentTimeMillis() + 86400000);

        Appointment appointment = new Appointment(
                "1234567890",
                futureDate,
                "Doctor appointment"
        );

        assertEquals("1234567890", appointment.getAppointmentId());
        assertEquals(futureDate, appointment.getAppointmentDate());
        assertEquals("Doctor appointment", appointment.getDescription());
    }

    @Test
    void testAppointmentIdCannotBeNull() {
        Date futureDate = new Date(System.currentTimeMillis() + 86400000);

        assertThrows(IllegalArgumentException.class, () ->
            new Appointment(null, futureDate, "Doctor appointment")
        );
    }

    @Test
    void testAppointmentIdCannotExceedTenCharacters() {
        Date futureDate = new Date(System.currentTimeMillis() + 86400000);

        assertThrows(IllegalArgumentException.class, () ->
            new Appointment("12345678901", futureDate, "Doctor appointment")
        );
    }

    @Test
    void testAppointmentDateCannotBeNull() {
        assertThrows(IllegalArgumentException.class, () ->
            new Appointment("12345", null, "Doctor appointment")
        );
    }

    @Test
    void testAppointmentDateCannotBeInThePast() {
        Date pastDate = new Date(System.currentTimeMillis() - 86400000);

        assertThrows(IllegalArgumentException.class, () ->
            new Appointment("12345", pastDate, "Doctor appointment")
        );
    }

    @Test
    void testDescriptionCannotBeNull() {
        Date futureDate = new Date(System.currentTimeMillis() + 86400000);

        assertThrows(IllegalArgumentException.class, () ->
            new Appointment("12345", futureDate, null)
        );
    }

    @Test
    void testDescriptionCannotExceedFiftyCharacters() {
        Date futureDate = new Date(System.currentTimeMillis() + 86400000);
        String longDescription = "This description contains more than fifty characters.";

        assertThrows(IllegalArgumentException.class, () ->
            new Appointment("12345", futureDate, longDescription)
        );
    }

    @Test
    void testAppointmentIdCannotBeUpdated() {
        Date futureDate = new Date(System.currentTimeMillis() + 86400000);

        Appointment appointment = new Appointment(
                "12345",
                futureDate,
                "Doctor appointment"
        );

        assertEquals("12345", appointment.getAppointmentId());
    }

    @Test
    void testAppointmentDateCanBeUpdated() {
        Date futureDate = new Date(System.currentTimeMillis() + 86400000);
        Date newFutureDate = new Date(System.currentTimeMillis() + 172800000);

        Appointment appointment = new Appointment(
                "12345",
                futureDate,
                "Doctor appointment"
        );

        appointment.setAppointmentDate(newFutureDate);

        assertEquals(newFutureDate, appointment.getAppointmentDate());
    }

    @Test
    void testDescriptionCanBeUpdated() {
        Date futureDate = new Date(System.currentTimeMillis() + 86400000);

        Appointment appointment = new Appointment(
                "12345",
                futureDate,
                "Doctor appointment"
        );

        appointment.setDescription("Updated appointment");

        assertEquals("Updated appointment", appointment.getDescription());
    }
}