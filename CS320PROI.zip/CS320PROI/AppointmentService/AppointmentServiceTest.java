import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertNull;

import java.util.Date;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class AppointmentServiceTest {

    private AppointmentService appointmentService;

    @BeforeEach
    void setUp() {
        appointmentService = new AppointmentService();
    }

    @Test
    void testAddAppointment() {
        Date futureDate = new Date(System.currentTimeMillis() + 86400000);

        Appointment appointment = new Appointment(
                "12345",
                futureDate,
                "Doctor appointment"
        );

        appointmentService.addAppointment(appointment);

        assertEquals(
                appointment,
                appointmentService.getAppointment("12345")
        );
    }

    @Test
    void testCannotAddDuplicateAppointment() {
        Date futureDate = new Date(System.currentTimeMillis() + 86400000);

        Appointment appointment1 = new Appointment(
                "12345",
                futureDate,
                "Doctor appointment"
        );

        Appointment appointment2 = new Appointment(
                "12345",
                futureDate,
                "Second appointment"
        );

        appointmentService.addAppointment(appointment1);

        assertThrows(IllegalArgumentException.class, () ->
            appointmentService.addAppointment(appointment2)
        );
    }

    @Test
    void testDeleteAppointment() {
        Date futureDate = new Date(System.currentTimeMillis() + 86400000);

        Appointment appointment = new Appointment(
                "12345",
                futureDate,
                "Doctor appointment"
        );

        appointmentService.addAppointment(appointment);
        appointmentService.deleteAppointment("12345");

        assertNull(appointmentService.getAppointment("12345"));
    }

    @Test
    void testCannotDeleteNonexistentAppointment() {
        assertThrows(IllegalArgumentException.class, () ->
            appointmentService.deleteAppointment("99999")
        );
    }

    @Test
    void testCannotAddNullAppointment() {
        assertThrows(IllegalArgumentException.class, () ->
            appointmentService.addAppointment(null)
        );
    }
}