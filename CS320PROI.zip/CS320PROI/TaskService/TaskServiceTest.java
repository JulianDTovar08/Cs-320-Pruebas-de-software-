import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class TaskServiceTest {

    private TaskService taskService;

    @BeforeEach
    void setUp() {
        taskService = new TaskService();
    }

    @Test
    void testAddTask() {

        Task task = new Task(
                "12345",
                "Homework",
                "Complete Java assignment."
        );

        taskService.addTask(task);

        assertNotNull(taskService.getTask("12345"));
        assertEquals("Homework", taskService.getTask("12345").getName());
    }

    @Test
    void testCannotAddDuplicateTaskId() {

        Task task1 = new Task(
                "12345",
                "Homework",
                "Complete Java assignment."
        );

        Task task2 = new Task(
                "12345",
                "Project",
                "Complete final project."
        );

        taskService.addTask(task1);

        assertThrows(IllegalArgumentException.class, () -> {
            taskService.addTask(task2);
        });
    }

    @Test
    void testDeleteTask() {

        Task task = new Task(
                "12345",
                "Homework",
                "Complete Java assignment."
        );

        taskService.addTask(task);
        taskService.deleteTask("12345");

        assertEquals(null, taskService.getTask("12345"));
    }

    @Test
    void testCannotDeleteNonexistentTask() {

        assertThrows(IllegalArgumentException.class, () -> {
            taskService.deleteTask("99999");
        });
    }

    @Test
    void testUpdateTaskName() {

        Task task = new Task(
                "12345",
                "Homework",
                "Complete Java assignment."
        );

        taskService.addTask(task);

        taskService.updateTask(
                "12345",
                "Updated Homework",
                "Complete Java assignment."
        );

        assertEquals(
                "Updated Homework",
                taskService.getTask("12345").getName()
        );
    }

    @Test
    void testUpdateTaskDescription() {

        Task task = new Task(
                "12345",
                "Homework",
                "Complete Java assignment."
        );

        taskService.addTask(task);

        taskService.updateTask(
                "12345",
                "Homework",
                "Updated description."
        );

        assertEquals(
                "Updated description.",
                taskService.getTask("12345").getDescription()
        );
    }

    @Test
    void testUpdateTask() {

        Task task = new Task(
                "12345",
                "Homework",
                "Complete Java assignment."
        );

        taskService.addTask(task);

        taskService.updateTask(
                "12345",
                "Final Homework",
                "Complete the final Java assignment."
        );

        assertEquals(
                "Final Homework",
                taskService.getTask("12345").getName()
        );

        assertEquals(
                "Complete the final Java assignment.",
                taskService.getTask("12345").getDescription()
        );
    }

    @Test
    void testCannotUpdateNonexistentTask() {

        assertThrows(IllegalArgumentException.class, () -> {
            taskService.updateTask(
                    "99999",
                    "Updated Task",
                    "Updated description."
            );
        });
    }
}