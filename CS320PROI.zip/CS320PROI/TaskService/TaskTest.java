import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.Test;

public class TaskTest {

    @Test
    void testTaskCreation() {

        Task task = new Task(
                "12345",
                "Homework",
                "Complete Java assignment."
        );

        assertEquals("12345", task.getTaskId());
        assertEquals("Homework", task.getName());
        assertEquals("Complete Java assignment.", task.getDescription());
    }

    @Test
    void testTaskIdCannotBeNull() {

        assertThrows(IllegalArgumentException.class, () -> {
            new Task(
                    null,
                    "Homework",
                    "Complete assignment."
            );
        });
    }

    @Test
    void testTaskIdCannotExceed10Characters() {

        assertThrows(IllegalArgumentException.class, () -> {
            new Task(
                    "12345678901",
                    "Homework",
                    "Complete assignment."
            );
        });
    }

    @Test
    void testTaskNameCannotBeNull() {

        assertThrows(IllegalArgumentException.class, () -> {
            new Task(
                    "12345",
                    null,
                    "Complete assignment."
            );
        });
    }

    @Test
    void testTaskNameCannotExceed20Characters() {

        assertThrows(IllegalArgumentException.class, () -> {
            new Task(
                    "12345",
                    "This task name is too long",
                    "Complete assignment."
            );
        });
    }

    @Test
    void testTaskDescriptionCannotBeNull() {

        assertThrows(IllegalArgumentException.class, () -> {
            new Task(
                    "12345",
                    "Homework",
                    null
            );
        });
    }

    @Test
    void testTaskDescriptionCannotExceed50Characters() {

        assertThrows(IllegalArgumentException.class, () -> {
            new Task(
                    "12345",
                    "Homework",
                    "This description is intentionally longer than fifty characters."
            );
        });
    }

    @Test
    void testTaskNameCanBeUpdated() {

        Task task = new Task(
                "12345",
                "Homework",
                "Complete assignment."
        );

        task.setName("Updated Task");

        assertEquals("Updated Task", task.getName());
    }

    @Test
    void testTaskDescriptionCanBeUpdated() {

        Task task = new Task(
                "12345",
                "Homework",
                "Complete assignment."
        );

        task.setDescription("Updated description.");

        assertEquals(
                "Updated description.",
                task.getDescription()
        );
    }

    @Test
    void testTaskIdCannotBeChanged() {

        Task task = new Task(
                "12345",
                "Homework",
                "Complete assignment."
        );

        assertEquals("12345", task.getTaskId());
    }
}